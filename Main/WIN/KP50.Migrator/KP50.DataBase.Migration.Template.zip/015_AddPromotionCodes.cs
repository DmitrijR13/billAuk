﻿using System.Data;
using KP50.DataBase.Migrator.Framework;
using MigrateDataBase = KP50.DataBase.Migrator.Framework.DataBase;

namespace $rootnamespace$
{
    // TODO: Set migration version as YYYYMMDDVVV
    // YYYY - Year
    // MM   - Month
    // DD   - Day
    // VVV  - Version
    [Migration(0, MigrateDataBase.CentralBank)]
    public class $fileinputname$_CentralBank : Migration
    {
        public override void Apply()
        {
            SetSchema(Bank.Kernel);
            // TODO: Upgrade CentralPref_Kernel

            SetSchema(Bank.Data);
            // TODO: Upgrade CentralPref_Data

            SetSchema(Bank.Upload);
            // TODO: Upgrade CentralPref_Upload
        }

        public override void Revert()
        {
            SetSchema(Bank.Kernel);
            // TODO: Downgrade CentralPref_Kernel

            SetSchema(Bank.Data);
            // TODO: Downgrade CentralPref_Data

            SetSchema(Bank.Upload);
            // TODO: Downgrade CentralPref_Upload
        }
    }

    // TODO: Set migration version as YYYYMMDDVVV
    // YYYY - Year
    // MM   - Month
    // DD   - Day
    // VVV  - Version
    [Migration(0, MigrateDataBase.LocalBank)]
    public class $fileinputname$_LocalBank : Migration
    {
        public override void Apply()
        {
            SetSchema(Bank.Kernel);
            // TODO: Upgrade LocalPref_Kernel

            SetSchema(Bank.Data);
            // TODO: Upgrade LocalPref_Data

        }

        public override void Revert()
        {
            SetSchema(Bank.Kernel);
            // TODO: Downgrade LocalPref_Kernel

            SetSchema(Bank.Data);
            // TODO: Downgrade LocalPref_Data

        }
    }

    // TODO: Set migration version as YYYYMMDDVVV
    // YYYY - Year
    // MM   - Month
    // DD   - Day
    // VVV  - Version
    [Migration(0, MigrateDataBase.Charge)]
    public class $fileinputname$_Charge : Migration
    {
        public override void Apply()
        {
            // TODO: Upgrade Charges

        }

        public override void Revert()
        {
            // TODO: Downgrade Charges

        }
    }

    // TODO: Set migration version as YYYYMMDDVVV
    // YYYY - Year
    // MM   - Month
    // DD   - Day
    // VVV  - Version
    [Migration(0, MigrateDataBase.Fin)]
    public class $fileinputname$_Fin : Migration
    {
        public override void Apply()
        {
            // TODO: Upgrade Fins

        }

        public override void Revert()
        {
            // TODO: Downgrade Fins

        }
    }

    // TODO: Set migration version as YYYYMMDDVVV
    // YYYY - Year
    // MM   - Month
    // DD   - Day
    // VVV  - Version
    [Migration(0, MigrateDataBase.Web)]
    public class $fileinputname$_Web : Migration
    {
        public override void Apply()
        {
            // TODO: Upgrade Web

        }

        public override void Revert()
        {
            // TODO: Downgrade Web

        }
    }
}
